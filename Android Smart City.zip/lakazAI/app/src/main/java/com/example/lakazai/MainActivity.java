package com.example.lakazai;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends Activity  {

    Button top_picks, plan_your_day, bookmarks, eating_places, fetch_location;
    public static final String mypreference = "mypref";



    @Override
    protected final void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        top_picks = (Button) findViewById(R.id.top);
        top_picks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent();
                i.setClass(MainActivity.this, Location.class);
                i.putExtra("Uniqid","From_Top_Picks");
                startActivity(i);
            }
        });



        plan_your_day = (Button) findViewById(R.id.plan);
        plan_your_day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent();
                i.setClass(MainActivity.this, Location.class);
                i.putExtra("Uniqid","From_Plan_Your_Day");
                startActivity(i);
            }
        });

        eating_places = (Button) findViewById(R.id.eat);
        eating_places.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent();
                i.setClass(MainActivity.this, Location.class);
                i.putExtra("Uniqid","From_Eating_Places");
                startActivity(i);
            }
        });
    }




}







